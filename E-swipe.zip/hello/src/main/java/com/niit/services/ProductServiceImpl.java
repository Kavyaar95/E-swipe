package com.niit.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.dao.ProductDao;
import com.niit.model.Product;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductDao productDao;

	public ProductDao getProductDao() {
		return productDao;
	}

	@Transactional
	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	@Transactional
	public List<Product> getAllProducts() {
		return productDao.getAllProducts();
	}

	
	@Transactional
	public void addProduct(Product product) {
		productDao.addProduct(product);
		
	}
@Transactional
	public void deleteProduct(int pid) {
		productDao.deleteProduct(pid);

	}
@Transactional
	public void editProduct(Product product) {
		productDao.editProduct(product);
		
	}

@Transactional
public Product getProductBypid(int pid) {
	// TODO Auto-generated method stub
	return productDao.getProductBypid(pid);
}



//@Override
//public Product getProductBypid(int pid) {
//	// TODO Auto-generated method stub
//	return null;
//}

//@Override
//public Product getProductBypid(int pid) {
//	// TODO Auto-generated method stub
//	return null;
//}

//@Override
//public Product getProductBypid(int pid) {
//	// TODO Auto-generated method stub
//	return null;
//}

	


}