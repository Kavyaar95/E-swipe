package com.niit.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="product")
public class Product {
	@Id
	@Column(name="pid")
	
	private int pid;
//	@NotEmpty(message="product description is mandatory")
	private String productDescription;
	private String Productmanufacturer;
	@NotEmpty(message="Product name is mandatory")
	private String Productname;
	@Min(value=100,message="Minimum value should be greater than 100")
	private double price;
	private int UnitInStock;
	@ManyToOne
	@JoinColumn(name="cid")
	@JsonIgnore
	private Category category;
	
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getProductmanufacturer() {
		return Productmanufacturer;
	}
	public void setProductmanufacturer(String productmanufacturer) {
		Productmanufacturer = productmanufacturer;
	}
	public String getProductname() {
		return Productname;
	}
	public void setProductname(String productname) {
		Productname = productname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getUnitInStock() {
		return UnitInStock;
	}
	public void setUnitInStock(int unitInStock) {
		UnitInStock = unitInStock;
	}
	@Transient
	private MultipartFile productImage;

	public MultipartFile getProductImage() {
		return productImage;
	}
	public void setProductImage(MultipartFile productImage) {
		this.productImage = productImage;
	}
	

}
