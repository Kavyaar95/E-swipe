package com.niit.dao;

import com.niit.model.CartItem;

public interface CartItemDao {
	void addCartItem(CartItem cartItem);
}
