package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.niit.model.Cart;
import com.niit.model.Customer;
import com.niit.model.Users;
import com.niit.services.CartItemService;
import com.niit.services.CustomerServices;
import com.niit.services.ProductService;

@Controller
@Transactional
public class CartItemController {
@Autowired
private CartItemService cartItemService;
@Autowired
private CustomerServices customerServices;
@Autowired
private ProductService productServices;


public CartItemService getCartItemService() {
	return cartItemService;
}


public void setCartItemService(CartItemService cartItemService) {
	this.cartItemService = cartItemService;
}


public CustomerServices getCustomerServices() {
	return customerServices;
}


public void setCustomerServices(CustomerServices customerServices) {
	this.customerServices = customerServices;
}




public ProductService getProductServices() {
	return productServices;
}


public void setProductServices(ProductService productServices) {
	this.productServices = productServices;
}


@RequestMapping("/cart/add/{isbn}")
@ResponseStatus(value=HttpStatus.NO_CONTENT)
public void addItem(@PathVariable(value = "pid") int pid){
	
	Users user=(Users)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	String username=user.getUsername();
	Customer customer=customerServices.getCustomerByUsername(username);
	System.out.println("Customer is " + customer.getCustomerEmail() );
	Cart cart=customer.getCart();
	
	

}


}
