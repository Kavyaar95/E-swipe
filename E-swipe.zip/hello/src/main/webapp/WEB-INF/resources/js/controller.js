var app=angular.module("app",[])
.controller("productController",function($scope,$http){

	$scope.getProductList = function(){
		   $http.get('http://localhost:8080/hello/getProductsList').success(function (data){
		       $scope.products = data;
		   });
	};

   $scope.addToCart=function(isbn){
	   $http.put('http://localhost:8080/hello/cart/add/'+pid).success(function(){
		   alert('Added Successfully');
	   });
   };

});
